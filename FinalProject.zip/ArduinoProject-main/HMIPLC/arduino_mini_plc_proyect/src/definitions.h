#ifndef DEFINITION
#define DEFINITION

#define OUT1 12
#define OUT2 10
#define OUT3 8
#define OUT4 6
#define IN1 5
#define IN2 6
#define IN3 7
#define IN4 8

#endif